import React from 'react'

const Tab = props => {
  const { activeTab, setActiveTab, allTabs } = props

  const tabStyle = index => {
    if (index === activeTab) {
      return 'Blue'
    }
  }

  return (
    <div>
      {allTabs.map((item, index) => (
        <button className={tabStyle(index)} onClick={e => setActiveTab(index)}>
          {' '}
          {item.title}
        </button>
      ))}
      <div>{allTabs[activeTab].content}</div>
    </div>
  )
}

export default Tab
